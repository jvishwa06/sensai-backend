import{g as u,bZ as n}from"./index.u-SbDkgZ.js";var o=n,i=0;function a(r){var t=++i;return o(r)+t}var e=a;const s=u(e);export{s as u};
